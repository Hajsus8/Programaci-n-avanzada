#include <iostream>

int** transpuestaMatriz(int** matriz, int n) {

    int** _transpuesta = new int* [n];

    for (int i = 0; i < n; i++) {

        _transpuesta[i] = new int[n];

        for (int j = 0; j < n; j++) {

            _transpuesta[i][j] = matriz[j][i];
        }
    }
    return _transpuesta;
}

int main() {

    int n = 3;

    int** matriz = new int* [n];

    // Inicializar la matriz original.
    for (int i = 0; i < n; i++) {
        matriz[i] = new int[n];
        for (int j = 0; j < n; j++) {
            matriz[i][j] = i * n + j;
        }
    }

    // Imprimir la matriz original.
    std::cout << "Matriz:\n";
    for (int i = 0; i < n; i++) {

        for (int j = 0; j < n; j++) {

            std::cout << matriz[i][j] << " ";
        }
        std::cout << std::endl;
    }

    int** matriz_transpuesta = transpuestaMatriz(matriz, n);

    // Imprimir la matriz transpuesta.

    std::cout << "Matriz transpuesta:\n";

    for (int i = 0; i < n; i++) {

        for (int j = 0; j < n; j++) {

            std::cout << matriz_transpuesta[i][j] << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}