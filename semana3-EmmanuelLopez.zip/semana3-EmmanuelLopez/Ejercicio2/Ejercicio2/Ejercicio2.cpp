#include <iostream>

int main() {
    int Dia, DiaExtra;

    std::cout << "Ingrese el dia de la semana en que inicia el ano (0 para Lunes, 1 para Martes, etc.): ";
    std::cin >> Dia;

    std::cout << "el ano es bisiesto? (1 para bisiesto, 0 para no bisiesto): ";
    std::cin >> DiaExtra;

    std::string diasSemana[7] = { "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo" };
    std::string meses[12] = { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" };

    int diasMes[12] = { 31, 28 + DiaExtra, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int dia = 1;

    for (int mes = 0; mes < 12; ++mes) {
        std::cout << "Calendario de " << meses[mes] << ":\n";
        std::cout << "------------------------\n";
        std::cout << "L   M   X   J   V   S   D\n";
        for (int i = 0; i < Dia; ++i) {
            std::cout << "    ";
        }
        for (int i = 1; i <= diasMes[mes]; ++i) {
            if (i < 10) {
                std::cout << " ";
            }
            std::cout << i << "  ";
            if ((i + Dia) % 7 == 0 || i == diasMes[mes]) {
                std::cout << "\n";
            }
        }
        std::cout << "\n";

        Dia = (Dia + diasMes[mes]) % 7;
    }

    return 0;
}